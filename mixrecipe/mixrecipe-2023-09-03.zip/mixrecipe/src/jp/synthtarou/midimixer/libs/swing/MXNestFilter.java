/*
 * Copyright 2023 Syntarou YOSHIDA.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package jp.synthtarou.midimixer.libs.swing;

import java.io.File;
import java.io.FileFilter;
import java.util.HashSet;

/**
 *
 * @author Syntarou YOSHIDA
 */
public class MXNestFilter implements FileFilter {

    HashSet<String> _listSuceed = new HashSet();
    HashSet<String> _listFailed = new HashSet();
    MXSwingFolderBrowser _owner;

    public MXNestFilter(MXSwingFolderBrowser ownwer) {
        _owner = ownwer;
    }

    public boolean accept(File file) {
        if (_listFailed.contains(file.toString())) {
            return false;
        }
        if (_listSuceed.contains(file.toString())) {
            return true;
        }
        try {
            boolean hit = false;
            File[] children = file.listFiles();
            if (children == null) {
                return false;
            }
            for (File child : children) {
                try {
                    if (child.isFile()) {
                        if (_owner.isOpenableFile(child)
                          || _owner.isVisibleFile(child)) {
                            _listSuceed.add(child.toString());
                            hit = true;
                        }
                    } else {
                        if (accept(child)) {
                            _listSuceed.add(child.toString());
                            hit = true;
                        }
                    }
                } catch (Throwable e) {
                    e.printStackTrace();
                }
            }

            if (hit) {
                _listSuceed.add(file.toString());
            }else {
                _listFailed.add(file.toString());
            }
            return hit;
        } catch (Throwable e) {
            e.printStackTrace();
        }

        _listFailed.add(file.toString());
        return false;
    }
}
