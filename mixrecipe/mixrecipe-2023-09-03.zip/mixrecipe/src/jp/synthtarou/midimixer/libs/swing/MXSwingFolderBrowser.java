/*
 * Copyright 2023 Syntarou YOSHIDA.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package jp.synthtarou.midimixer.libs.swing;

import java.awt.Component;
import java.awt.Dimension;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileFilter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.TreeSet;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTree;
import javax.swing.SwingUtilities;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.filechooser.FileSystemView;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeCellRenderer;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreeCellRenderer;
import javax.swing.tree.TreePath;
import jp.synthtarou.midimixer.libs.common.MXUtil;
import jp.synthtarou.midimixer.mx35cceditor.prompt.IPromptPanel;

/**
 *
 * @author Syntarou YOSHIDA
 */
public class MXSwingFolderBrowser extends javax.swing.JPanel implements IPromptPanel {

    static final int DISKDRIVE_DEPTH = 20;

    class Alive {

        Throwable e = new Throwable();
        long tick = System.currentTimeMillis();

        public long distance() {
            return System.currentTimeMillis() - tick;
        }

        public void dump() {
            e.printStackTrace();
        }
    }

    HashMap<Thread, Alive> _test = new HashMap();

    abstract class Runnable2 {

        static boolean _disableThreading = false;

        public Runnable2() {
        }

        public final void launchStay(File file, DefaultMutableTreeNode node) {
            try {
                process(file, node);
            } catch (Throwable e) {
                e.printStackTrace();;
            } finally {
            }
        }

        public final void launchProcess(File file, DefaultMutableTreeNode node) {
            if (_disableThreading) {
                launchStay(file, node);
            } else {
                Thread t = new Thread() {
                    public void run() {
                        try {
                            launchStay(file, node);
                        } finally {
                            synchronized (_test) {
                                Collection<Alive> seek = _test.values();
                                for (Alive a : seek) {
                                    if (a.distance() >= 100000) {
                                        //System.out.println("Distance " + a.distance());
                                        //a.dump();
                                        //_test.remove(a);
                                    }
                                }
                            }
                        }
                    }
                };
                synchronized (_test) {
                    _test.put(t, new Alive());
                }
                t.start();
            }
        }

        public final void launchUIThread(File file, DefaultMutableTreeNode node) {
            try {
                SwingUtilities.invokeAndWait(new Runnable() {
                    public void run() {
                        process(file, node);
                    }
                });
            } catch (Throwable e) {
                e.printStackTrace();
            }
        }

        protected abstract void process(File file, DefaultMutableTreeNode node);
    }

    DefaultMutableTreeNode _networkNode = null;

    static FileSystemView _fileSystem = FileSystemView.getFileSystemView();
    DefaultTreeModel _model;
    File[] _selection;
    File[] _result = null;

    FileFilter _filterOpenable = null;
    FileFilter _filterVisible = null;
    File _curerntDirectory = null;

    MXNestFilter _deepScan = new MXNestFilter(this);

    public static void main(String[] args) {

        MXSwingFolderBrowser c0 = new MXSwingFolderBrowser(new File("C:/Program Files/Common Files"), null);
        MXModalFrame.showAsDialog(null, c0, "Standard");

        FileFilter filterxml = new FileFilterListExt(new String[]{".xml"});
        MXSwingFolderBrowser c1 = new MXSwingFolderBrowser(new File("C:/Domino144/Module"), filterxml);
        MXModalFrame.showAsDialog(null, c1, "Domino XML");

        FileFilter filtervst = new FileFilterListExt(new String[]{".vst3"});
        MXSwingFolderBrowser c2 = new MXSwingFolderBrowser(null, filtervst);
        MXModalFrame.showAsDialog(null, c2, "VST3");

        FileFilter filtermid = new FileFilterListExt(new String[]{".mid"});
        MXSwingFolderBrowser c3 = new MXSwingFolderBrowser(new File("C:/"), filtermid);
        MXModalFrame.showAsDialog(null, c3, "MID File");

        System.exit(0);
    }

    public static final boolean APPROVE_OPTION = true;
    public static final boolean CANCEL_OPTION = false;

    public File[] getSelectedFileList() {
        return _result;
    }

    public MXSwingFolderBrowser(File initialDir, FileFilter filterOpenable) {
        this(initialDir, filterOpenable, null);
    }

    boolean _init = true;
    File _initialDir = null;

    public MXSwingFolderBrowser(File initialDir, FileFilter filterOpenable, FileFilter filterVisible) {
        initComponents();

        _curerntDirectory = initialDir;
        _filterOpenable = filterOpenable;
        _filterVisible = filterVisible;

        jLabel2.setText("");

        DefaultMutableTreeNode root = new DefaultMutableTreeNode(null);
        root.setAllowsChildren(true);

        _model = new DefaultTreeModel(root);
        _model.setAsksAllowsChildren(true);

        jTree1.setCellRenderer(new MyRenderer());
        jTree1.setRootVisible(false);
        jTree1.setModel(_model);

        jTree1.addTreeSelectionListener(new TreeSelectionListener() {
            @Override
            public void valueChanged(TreeSelectionEvent e) {
                if (_init) {
                    return;
                }
                viewSelection();
            }
        });

        jTree1.setRequestFocusEnabled(true);
        jTree1.requestFocusInWindow();

        setPreferredSize(new Dimension(550, 350));

        _initialDir = initialDir;
        InitialRun init = new InitialRun();

        init.launchProcess(null, root);
    }

    class DigRun extends Runnable2 {

        @Override
        public void process(File initialDir, DefaultMutableTreeNode dummy) {
            LinkedList<File> seekPath = new LinkedList();
            File seek = initialDir;
            if (seek == null) {
                return;
            }
            seekPath.add(seek);
            while (true) {
                File parent = seek.getParentFile();
                if (parent == null) {
                    break;
                }
                seek = parent;
                seekPath.add(seek);

            }

            FileSystemCache.Element lastParent = null;
            System.out.println("Path To Build " + seekPath);

            while (seekPath.isEmpty() == false) {
                File file = seekPath.removeLast();
                FileSystemCache.Element node = _cache.getCache1(file);

                if (node == null) {
                    if (lastParent != null) {
                        fillSubDirectory(lastParent);
                        lastParent = _cache.getCache1(file);

                        if (lastParent == null) {
                            System.out.println("Wrong Directory Seek");
                            return;
                        }
                    } else {
                        FileSystemCache.Element root = _cache.getRoot1();
                        fillSubDirectory(root);
                        node = _cache.getCache1((File) null);
                    }
                } else {
                    lastParent = node;
                }
            }
            if (lastParent != null) {
                ensureNodeToVisible(lastParent);
            }
        }
    }

    class StepRun extends Runnable2 {

        @Override
        public void process(File file, DefaultMutableTreeNode fileNode) {
            FileSystemCache.Element element = _cache.getCache1(file);

            if (element == null) {
                element = _cache.addCache(file, fileNode);
            }
            fillSubDirectory(element);
        }
    }

    class InitialRun extends Runnable2 {

        int forceCount = 3;

        public boolean isProcessDrivesUnder(FileSystemCache.Element itsPC) {
            boolean hasDrive = false;
            File[] nest = null;
            try {
                if (itsPC._fileObject.isDirectory()) {
                    if (isCancelReasonNetwork(itsPC._fileObject)) {
                        return false;
                    }
                    nest = itsPC._fileObject.listFiles();
                }
            } catch (Throwable ex) {
                new IOException("**************************", ex).printStackTrace();
            }
            if (nest == null) {
                return false;
            }
            for (File disk : nest) {
                if (FileSystemCache.isDrive(disk)) {
                    hasDrive = true;
                }
            }
            if (hasDrive) {
                int z = 0;
                fillSubDirectory(itsPC);
                for (File disk : nest) {
                    if (FileSystemCache.isDrive(disk)) {
                        System.out.println("disk node " + disk);
                        DefaultMutableTreeNode diskNode = new DefaultMutableTreeNode(disk);
                        fillSubDirectory(_cache.addCache(disk, diskNode));
                    }
                }
                return true;
            }
            return false;
        }

        @Override
        public void process(File parentFile, DefaultMutableTreeNode parentNode) {
            if (parentNode == null) {
                throw new NullPointerException();
            }

            fillSubDirectory(_cache.addCache(parentFile, parentNode));
            File[] files = null;
            if (parentFile == null) {
                files = _fileSystem.getRoots();
            } else {
                if (isCancelReasonNetwork(parentFile)) {
                    return;
                }

                files = parentFile.listFiles();
                if (files == null) {
                    return;
                }

            }
            for (File file : files) {
                if (forceCount >= 0) {
                    forceCount--;
                    System.out.println("Force thru " + file);
                } else {
                    if (FileSystemCache.isUniqueNamed(file) == false) {
                        continue;
                    }
                }
                if (isCancelReasonNetwork(file)) {
                    continue;
                }

                DefaultMutableTreeNode node = new DefaultMutableTreeNode(file);
                node.setAllowsChildren(true);
                
                FileSystemCache.Element isPC = _cache.addCache(file, node);
                fillSubDirectory(isPC);

                if (isProcessDrivesUnder(isPC)) {
                    DigRun dig = new DigRun();
                    _init = false;
                    jTree1.updateUI();
                    dig.launchProcess(_initialDir, null);
                    return;
                } else {
                    process(file, node);
                }
            }
        }
    }

    long step;
    
    TreeSet<File> _alreadySeek = new TreeSet();
    boolean _alreaydNull = false;
    
    public synchronized void fillSubDirectory(FileSystemCache.Element parent) {
        File[] listFiles = null;
        _continueScan = true;
        
        File f = parent._fileObject;
        
        if (f == null) {
            if (_alreaydNull) {
                return;
            }
            _alreaydNull = true; 
        }
        else {
           if (_alreadySeek.contains(f)) {
                return;
            }
            _alreadySeek.add(parent._fileObject);
        }

        try {
            step++;
            if ((step % 50) == 0) {
                progress(step + "  / scanning " + parent);
            }

            if (parent._fileObject == null) {
                listFiles = _fileSystem.getRoots();
            } else {
                if (isCancelReasonNetwork(parent._fileObject)) {
                    return;
                }
                listFiles = parent._fileObject.listFiles();
            }
        } finally {
            _continueScan = false;
        }

        if (listFiles == null) {
            System.out.println("Bad Three");
            return;
        }
        for (File seek : listFiles) {
            if (jCheckBoxNested.isSelected()) {
                if (_deepScan.accept(seek) == false) {
                    continue;
                }
            }
            if (isVisibleFile(seek) == false) {
                continue;
            }
            DefaultMutableTreeNode child = new DefaultMutableTreeNode(seek);
            if (seek.isFile()) {
                child.setAllowsChildren(false);
            } else {
                child.setAllowsChildren(true);
            }
            FileSystemCache.Element element = _cache.addCache(seek, child);
            _model.insertNodeInto(child, parent._pairNode, parent._pairNode.getChildCount());
        }
    }

    FileSystemCache _cache = new FileSystemCache();

    public void viewSelection() {
        TreePath[] list = jTree1.getSelectionPaths();
        if (list != null) {
            ArrayList<File> result = new ArrayList<>();

            for (TreePath path : list) {
                DefaultMutableTreeNode node = (DefaultMutableTreeNode) path.getLastPathComponent();
                File f = (File) node.getUserObject();
                result.add(f);
            }

            if (result.size() > 0) {
                _selection = new File[result.size()];
                result.toArray(_selection);
            } else {
                _selection = null;
            }
            if (_selection == null) {
                jLabelSelection.setText("-");
            } else {
                jLabelSelection.setText(result.toString());
            }
        }
    }

    boolean _continueScan;

    public LinkedList<File> separateDirectory(File file) {
        LinkedList<File> path = new LinkedList<>();
        while (file.exists() == false) {
            file = file.getParentFile();
            if (file == null) {
                return path;
            }
        }
        path.add(0, file);
        while (true) {
            File parent = file.getParentFile();
            if (parent == null) {
                break;
            }
            path.addFirst(parent);
            file = parent;
        }
        return path;
    }

    public void ensureNodeToVisible(FileSystemCache.Element node) {
        if (node == null) {
            throw new NullPointerException("NULLPO");
        }
        if (SwingUtilities.isEventDispatchThread() == false) {
            SwingUtilities.invokeLater(new Runnable() {
                @Override
                public void run() {
                    ensureNodeToVisible(node);
                }
            });
            return;
        }
        TreePath path = new TreePath(node._pairNode.getPath());
        jTree1.expandPath(path);
        jTree1.setSelectionPath(path);

        jTree1.scrollPathToVisible(path);
        jTree1.paintImmediately(jTree1.getVisibleRect());
    }

    public boolean isCancelReasonNetwork(File f) {
        if (f == null) {
            return false;
        }
        if (f.getPath().startsWith("::")) {
            if (f.toString().equals("ネットワーク")
                    || f.toString().equalsIgnoreCase("network")) {
                if (jCheckBoxNetwork.isSelected() == false) {
                    return true;
                }
            }
        }
        return false;
    }

    public boolean isVisibleFile(File target) {
        if (_filterVisible != null) {
            if (_filterVisible.accept(target) == false) {
                return false;
            }
        } else if (_filterOpenable != null) {
            if (_filterOpenable.accept(target) == false) {
                return false;
            }
        }

        return true;
    }

    public boolean isOpenableFile(File target) {
        if (_filterOpenable != null) {
            return _filterOpenable.accept(target);
        }

        return true;
    }

    @Override
    public JPanel getAsPanel() {
        return this;
    }

    @Override
    public String getPanelTitle() {
        return "Folder Browser";
    }

    @Override
    public Dimension getPanelSize() {
        return new Dimension(500, 300);

    }

    static class MyRenderer extends DefaultTreeCellRenderer {

        private TreeCellRenderer _defRenderer;
        private FileSystemView _view;

        MyRenderer() {
            _defRenderer = new JTree().getCellRenderer();
            _view = FileSystemView.getFileSystemView();
        }

        @Override
        public Component getTreeCellRendererComponent(JTree tree, Object value, boolean selected,
                boolean expanded, boolean leaf, int row, boolean hasFocus) {
            Component component = _defRenderer.getTreeCellRendererComponent(tree, value, selected, expanded, leaf, row, hasFocus);

            if (value instanceof DefaultMutableTreeNode) {
                DefaultMutableTreeNode node = (DefaultMutableTreeNode) value;
                Object user = node.getUserObject();
                if (user != null && user instanceof File) {
                    File file = (File) node.getUserObject();
                    JLabel label = (JLabel) component;
                    label.setIcon(_view.getSystemIcon(file));
                    label.setText(_view.getSystemDisplayName(file));
                    label.setToolTipText(file.getPath());
                }
            }

            return component;
        }
    }

    public void progress(String text) {
        if (SwingUtilities.isEventDispatchThread() == false) {
            SwingUtilities.invokeLater(new Runnable() {
                public void run() {
                    progress(text);
                }
            });
            return;
        }
        jLabelScan.setText(text);
        jLabelScan.paintImmediately(jLabelScan.getVisibleRect());
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        java.awt.GridBagConstraints gridBagConstraints;

        jButtonOK = new javax.swing.JButton();
        jButtonCancel = new javax.swing.JButton();
        jLabelSelection = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTree1 = new javax.swing.JTree();
        jLabel2 = new javax.swing.JLabel();
        jCheckBoxNetwork = new javax.swing.JCheckBox();
        jCheckBoxNested = new javax.swing.JCheckBox();
        jLabelScan = new javax.swing.JLabel();
        jProgressBar1 = new javax.swing.JProgressBar();
        jButtonStopScan = new javax.swing.JButton();

        addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                formKeyPressed(evt);
            }
        });
        setLayout(new java.awt.GridBagLayout());

        jButtonOK.setText("Enter");
        jButtonOK.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonOKActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        add(jButtonOK, gridBagConstraints);

        jButtonCancel.setText("Cancel");
        jButtonCancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonCancelActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        add(jButtonCancel, gridBagConstraints);

        jLabelSelection.setText("Please Select 1 From Tree");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.gridwidth = 4;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        add(jLabelSelection, gridBagConstraints);

        jTree1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTree1MouseClicked(evt);
            }
        });
        jTree1.addTreeWillExpandListener(new javax.swing.event.TreeWillExpandListener() {
            public void treeWillCollapse(javax.swing.event.TreeExpansionEvent evt)throws javax.swing.tree.ExpandVetoException {
            }
            public void treeWillExpand(javax.swing.event.TreeExpansionEvent evt)throws javax.swing.tree.ExpandVetoException {
                jTree1TreeWillExpand(evt);
            }
        });
        jTree1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jTree1KeyPressed(evt);
            }
        });
        jScrollPane1.setViewportView(jTree1);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 3;
        gridBagConstraints.gridwidth = 3;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 1.0;
        add(jScrollPane1, gridBagConstraints);

        jLabel2.setText("-hide");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.weightx = 1.0;
        add(jLabel2, gridBagConstraints);

        jCheckBoxNetwork.setText("Unlock Network Access");
        jCheckBoxNetwork.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBoxNetworkActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        add(jCheckBoxNetwork, gridBagConstraints);

        jCheckBoxNested.setText("Rich Scan");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        add(jCheckBoxNested, gridBagConstraints);

        jLabelScan.setText("-");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 4;
        gridBagConstraints.gridwidth = 2;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        add(jLabelScan, gridBagConstraints);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 5;
        gridBagConstraints.gridwidth = 3;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        add(jProgressBar1, gridBagConstraints);

        jButtonStopScan.setText("Stop scan");
        jButtonStopScan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonStopScanActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 4;
        add(jButtonStopScan, gridBagConstraints);
    }// </editor-fold>//GEN-END:initComponents

    private void jButtonOKActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonOKActionPerformed
        setResultAndClose(_selection);
    }//GEN-LAST:event_jButtonOKActionPerformed

    private void jButtonCancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonCancelActionPerformed
        setResultAndClose(null);
    }//GEN-LAST:event_jButtonCancelActionPerformed

    private void jTree1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTree1MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_jTree1MouseClicked

    private void jTree1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTree1KeyPressed
        switch (evt.getExtendedKeyCode()) {
            case KeyEvent.VK_ENTER:
                setResultAndClose(_selection);
                return;
            case KeyEvent.VK_ESCAPE:
                setResultAndClose(null);
                return;
        }
    }//GEN-LAST:event_jTree1KeyPressed

    private void formKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_formKeyPressed
        switch (evt.getExtendedKeyCode()) {
            case KeyEvent.VK_ENTER:
                setResultAndClose(_selection);
                return;
            case KeyEvent.VK_ESCAPE:
                setResultAndClose(null);
                return;
        }
    }//GEN-LAST:event_formKeyPressed

    private void jCheckBoxNetworkActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBoxNetworkActionPerformed
        // TODO add your handling code here:
        if (_networkNode != null) {
            new StepRun().launchProcess((File) _networkNode.getUserObject(), _networkNode);
        }
    }//GEN-LAST:event_jCheckBoxNetworkActionPerformed

    private void jButtonStopScanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonStopScanActionPerformed
        _continueScan = false;
    }//GEN-LAST:event_jButtonStopScanActionPerformed

    private void jTree1TreeWillExpand(javax.swing.event.TreeExpansionEvent evt)throws javax.swing.tree.ExpandVetoException {//GEN-FIRST:event_jTree1TreeWillExpand
        if (_init) {
            return;
        }
        TreePath path = evt.getPath();
        DefaultMutableTreeNode last = (DefaultMutableTreeNode) path.getLastPathComponent();
        File file = (File) last.getUserObject();

        new StepRun().launchProcess(file, last);

    }//GEN-LAST:event_jTree1TreeWillExpand

    public void setResultAndClose(File[] result) {
        if (result == null) {
            _result = null;
            MXUtil.getOwnerWindow(this).setVisible(false);
            return;
        }
        ArrayList<File> safe = new ArrayList<File>();
        ArrayList<File> error = new ArrayList<File>();
        for (File temp : result) {
            if (isOpenableFile(temp)) {
                safe.add(temp);
            } else {
                error.add(temp);
            }
        }
        if (error.size() > 0) {
            JOptionPane.showMessageDialog(this, "Can't open " + error, "Notice", JOptionPane.OK_OPTION);
            return;
        }
        if (safe.size() == 0) {
            JOptionPane.showMessageDialog(this, "Not selected", "Notice", JOptionPane.OK_OPTION);
            return;
        }
        File[] finalAnswer = new File[safe.size()];
        safe.toArray(finalAnswer);
        _result = finalAnswer;
        MXUtil.getOwnerWindow(this).setVisible(false);
    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonCancel;
    private javax.swing.JButton jButtonOK;
    private javax.swing.JButton jButtonStopScan;
    private javax.swing.JCheckBox jCheckBoxNested;
    private javax.swing.JCheckBox jCheckBoxNetwork;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabelScan;
    private javax.swing.JLabel jLabelSelection;
    private javax.swing.JProgressBar jProgressBar1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTree jTree1;
    // End of variables declaration//GEN-END:variables
}
