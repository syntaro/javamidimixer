/*
 * Copyright 2023 Syntarou YOSHIDA.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package jp.synthtarou.midimixer.libs.swing;

import java.io.File;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.TreeMap;
import javax.swing.filechooser.FileSystemView;
import javax.swing.tree.DefaultMutableTreeNode;

/**
 *
 * @author Syntarou YOSHIDA
 */
public class FileSystemCache {

    File _fileSystem;
    String _path;
    DefaultMutableTreeNode _treeNode;
    static FileSystemView _view = FileSystemView.getFileSystemView();
    
    public static class Element implements Comparable<Element> {

        public final String _path;
        public final File _fileObject;
        public final DefaultMutableTreeNode _pairNode;

        public Element(File file, DefaultMutableTreeNode node) {
            _path = file == null ? null : file.toString();
            _fileObject = file;
            _pairNode = node;
        }

        @Override
        public int compareTo(Element o) {
            int x = _path.compareTo(o._path);
            if (x == 0) {
                x = _fileObject.compareTo(o._fileObject);
            }
            return x;
        }
        
        public String toString() {
            return _path == null ? "" : _path.toString();
        }
    }

    public static class ElementList {

        public ElementList(String path) {
            _path = path;
            _elements = new LinkedList();
            if (path == null) {
                _elements.add(new Element(null, new DefaultMutableTreeNode(null)));
            }
        }
        public final String _path;
        public final List<Element> _elements;
    }
    
    public final ElementList _listroot = new ElementList(null);
    
    TreeMap<String, ElementList> _cache = new TreeMap();

    public List<Element> getRoot() {
        return getCache((String)null);
    }

    public Element getRoot1() {
        return getCache((String)null).get(0);
    }
    
    public List<Element> getCache(String path) {
        if (path == null) {
            return _listroot._elements;
        }
        ElementList c = _cache.get(path);
        if (c == null) {
            return null;
        }
        return c._elements;
    }

    public List<Element> getCache(File path) {
        return getCache(path == null ? null : path.toString());
    }

    public List<Element> getCache(DefaultMutableTreeNode node) {
        File f = node == null ? null : ((File)node.getUserObject());
        return getCache(f);
    }

    public static boolean isDrive(File hdd) {
        if (hdd == null) {
            return false;
        }
        String path = hdd.toString();
        char[] text = path.toCharArray();
        if (text.length >= 2 && text.length <= 3) {
            if (text[1] == ':') {
                return true;
            }
        }
        if (text.length == 1) {
            if (text[0] == '/') {
                return true;
            }
        }
        return false;
    }

    public static boolean isUniqueNamed(File file) {
        if (file == null) {
            return false;
        }
        String path = file.getPath();
        String text = file.toString();
        if (path.equals(text)) {
            return false;
        }
        return true;
    }

    public Element getCache1(String path) {
        List<Element> ret = getCache(path);
        if (ret == null) {
            return null;
        }
        if (ret.size() == 0) {
            return null;
        }
        if (ret.size() == 1) {
            return ret.get(0);
        }
        for (Element e : ret) {
            File f = e._fileObject;
            while (f != null) {
                try {
                    f = f.getParentFile();
                    if (f != null && isDrive(f) && f.getParentFile() == null) {
                        return e;
                    }
                    if (f != null && isUniqueNamed(f)) {
                        break;
                    }
                }catch(Exception ex) {
                    ex.printStackTrace();
                }
            }
        }
        return ret.get(0);
    }

    public Element getCache1(File path) {
        return getCache1(path == null ? (String)null : path.toString());
    }
    
    public Element getCache1(DefaultMutableTreeNode node) {
        return getCache1((File)node.getUserObject());
    }

    Element addCache(File file, DefaultMutableTreeNode node) {
        String path = file == null ? "" : file.toString();
        ElementList c = path == null ? _listroot : _cache.get(path);
        if (c == null) {
            c = new ElementList(path);
            _cache.put(path, c);
        }
        Element newE = new Element(file, node);
        for (Element e : c._elements) {
            if (e.compareTo(newE) == 0) {
                return e;
            }
        }
        c._elements.add(newE);
        return newE;
    }
}
