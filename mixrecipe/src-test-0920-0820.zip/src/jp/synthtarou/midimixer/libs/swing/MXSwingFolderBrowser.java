/*
 * Copyright 2023 Syntarou YOSHIDA.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package jp.synthtarou.midimixer.libs.swing;

import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileFilter;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.TreeMap;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTree;
import javax.swing.SwingUtilities;
import javax.swing.event.TreeExpansionEvent;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.event.TreeWillExpandListener;
import javax.swing.filechooser.FileSystemView;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeCellRenderer;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.ExpandVetoException;
import javax.swing.tree.TreeCellRenderer;
import javax.swing.tree.TreePath;
import jp.synthtarou.midimixer.libs.common.MXUtil;
import jp.synthtarou.midimixer.mx35cceditor.prompt.IPromptPanel;

/**
 *
 * @author Syntarou YOSHIDA
 */
public class MXSwingFolderBrowser extends javax.swing.JPanel implements IPromptPanel {

    DefaultMutableTreeNode _networkNode = null;

    FileSystemView _view = FileSystemView.getFileSystemView();
    DefaultTreeModel _model;
    HashSet<DefaultMutableTreeNode> _cacheExpanded;
    TreeMap<File, DefaultMutableTreeNode> _cacheFileNode;
    boolean _onlyDirectory = false;
    File _selection;
    File _result = null;

    FileFilter _onlyFilter = null;
    File _curerntDirectory = null;

    public void setOnlyDirectory(boolean dirOnly) {
        _onlyDirectory = dirOnly;
    }

    public static void main(String[] args) {
        FileFilter filter = new MXFileFilter(new String[]{".xml"});
        MXSwingFolderBrowser chooser = new MXSwingFolderBrowser(new File("C:/Domino144/Module"), filter);
        chooser.showOpenDialog(null);
        System.out.println("Return " + chooser.getSelectedFile());
    }

    public static final boolean APPROVE_OPTION = true;
    public static final boolean CANCEL_OPTION = false;

    public boolean showOpenDialog(Container parent) {
        MXUtil.showAsDialog(parent, this, "FolderPicker");
        if (_result != null) {
            if (_result.exists()) {
                return true;
            } else {
                _result = null;
            }
        }
        return false;
    }

    public File getSelectedFile() {
        return _result;
    }

    /**
     * Creates new form MXFolderChooser
     */
    public MXSwingFolderBrowser(File initialDir, FileFilter filter) {
        initComponents();

        _cacheExpanded = new HashSet();
        _cacheFileNode = new TreeMap();
        _curerntDirectory = initialDir;
        _onlyFilter = filter;

        jLabel2.setText("");

        DefaultMutableTreeNode node = new DefaultMutableTreeNode(null);
        node.setAllowsChildren(true);
        File[] listRoot = _view.getRoots();
        for (File file : listRoot) {
            DefaultMutableTreeNode childNode = new DefaultMutableTreeNode(file);
            node.add(childNode);
            childNode.setAllowsChildren(true);
        }

        _model = new DefaultTreeModel(node);
        _model.setAsksAllowsChildren(true);

        jTree1.setCellRenderer(new MyRenderer());
        jTree1.setRootVisible(false);
        jTree1.addTreeWillExpandListener(new TreeWillExpandListener() {
            @Override
            public void treeWillExpand(TreeExpansionEvent event) throws ExpandVetoException {
                TreePath path = event.getPath();
                DefaultMutableTreeNode last = (DefaultMutableTreeNode) path.getLastPathComponent();
                expandNode(last, null);

            }

            @Override
            public void treeWillCollapse(TreeExpansionEvent event) throws ExpandVetoException {
            }
        });
        jTree1.setModel(_model);

        jTree1.addTreeSelectionListener(new TreeSelectionListener() {
            @Override
            public void valueChanged(TreeSelectionEvent e) {
                TreePath path = e.getNewLeadSelectionPath();
                if (path != null) {
                    DefaultMutableTreeNode node = (DefaultMutableTreeNode) path.getLastPathComponent();
                    File f = (File) node.getUserObject();
                    _selection = f;
                    if (f == null) {
                        jLabelSelection.setText("-");
                    } else {
                        jLabelSelection.setText(f.toString());
                    }
                }
            }
        });

        jTree1.setRequestFocusEnabled(true);
        jTree1.requestFocusInWindow();
        if (initialDir == null) {
            initialDir = new File("C:/");
            if (initialDir.exists() == false) {
                initialDir = new File("/");
            }
        }
        selectFile(initialDir);

        setPreferredSize(new Dimension(550, 350));
    }

    public void expandNode(DefaultMutableTreeNode node, Runnable whenFinished) {
        Runnable run = new Runnable() {
            @Override
            public void run() {
                File file = (File) node.getUserObject();

                if (_cacheExpanded.contains(node) == false && file != null) {
                    if (isNetworkFolder(file)) {
                        if (jCheckBoxNetwork.isSelected() == false) {
                            return;
                        }
                    }

                    _cacheExpanded.add(node);

                    File[] children = null;
                    children = file.listFiles();
                    for (File seek : children) {
                        if (!_cacheFileNode.containsKey(seek)) {
                            DefaultMutableTreeNode child = new DefaultMutableTreeNode(seek);
                            _cacheFileNode.put(seek, child);
                            if (seek.isFile()) {
                                child.setAllowsChildren(false);
                            } else {
                                child.setAllowsChildren(true);
                            }
                            node.add(child);
                        }
                    }
                    jTree1.expandPath(new TreePath(node.getPath()));
                }
                if (whenFinished != null) {
                    whenFinished.run();
                }
            }
        };
        if (whenFinished == null) {
            run.run();;
        } else {
            Thread t = new Thread(run);
            t.setPriority(Thread.MIN_PRIORITY);
            t.start();
        }
    }

    public LinkedList<File> separateDirectory(File file) {
        LinkedList<File> path = new LinkedList<>();
        while (file.exists() == false) {
            file = file.getParentFile();
            if (file == null) {
                return path;
            }
        }
        path.add(0, file);
        while (true) {
            File parent = file.getParentFile();
            if (parent == null) {
                break;
            }
            path.addFirst(parent);
            file = parent;
        }
        return path;
    }

    public void selectFile(File target) {
        Thread back = new Thread(new Runnable() {
            @Override
            public void run() {
                DefaultMutableTreeNode root = (DefaultMutableTreeNode) _model.getRoot();
                expandNode(root, null);

                DefaultMutableTreeNode desktop = (DefaultMutableTreeNode) root.getChildAt(0);
                expandNode(desktop, null);

                for (int i = 0; i < desktop.getChildCount(); ++i) {
                    DefaultMutableTreeNode computer = (DefaultMutableTreeNode) desktop.getChildAt(i);
                    File f = (File) computer.getUserObject();
                    if (f.getPath().startsWith("::")) {
                        if (f.toString().equals("ライブラリ")) {
                            continue;
                        }
                        expandNode(computer, null);
                    }
                }

                TreePath path = null;
                LinkedList<File> filePath = separateDirectory(target);
                for (File file : filePath) {
                    DefaultMutableTreeNode cached = _cacheFileNode.get(file);
                    if (cached == null) {
                        continue;
                    }
                    expandNode(cached, null);
                    TreePath tmp = new TreePath(cached.getPath());
                    path = tmp;
                }
                jTree1.expandPath(path);
                jTree1.setSelectionPath(path);
                jTree1.scrollPathToVisible(path);
                jTree1.revalidate();
            }
        });
        back.setPriority(Thread.MIN_PRIORITY);
        back.start();;
    }

    public boolean isNetworkFolder(File f) {
        if (f.getPath().startsWith("::")) {
            if (f.toString().equals("ネットワーク")
                    || f.toString().equalsIgnoreCase("network")) {
                return true;
            }
        }
        return false;
    }

    public boolean isTargetVisible(File target) {
        if (target.isDirectory() == false) {
            if (_onlyFilter.accept(target)) {
                return true;
            }
            return false;
        }
        return true;
    }

    public boolean isTargetOpenable(File target) {
        if (isTargetVisible(target)) {
            if (_onlyDirectory) {
                return target.isDirectory();
            }
            return true;
        }
        return false;
    }

    @Override
    public JPanel getAsPanel() {
        return this;
    }

    @Override
    public String getPanelTitle() {
        return "Folder Browser";
    }

    @Override
    public Dimension getPanelSize() {
        return new Dimension(500, 300);

    }

    static class MyRenderer extends DefaultTreeCellRenderer {

        private TreeCellRenderer _defRenderer;
        private FileSystemView _view;

        MyRenderer() {
            _defRenderer = new JTree().getCellRenderer();
            _view = FileSystemView.getFileSystemView();
        }

        @Override
        public Component getTreeCellRendererComponent(JTree tree, Object value, boolean selected,
                boolean expanded, boolean leaf, int row, boolean hasFocus) {
            Component component = _defRenderer.getTreeCellRendererComponent(tree, value, selected, expanded, leaf, row, hasFocus);

            if (value instanceof DefaultMutableTreeNode) {
                DefaultMutableTreeNode node = (DefaultMutableTreeNode) value;
                Object user = node.getUserObject();
                if (user != null && user instanceof File) {
                    File file = (File) node.getUserObject();
                    JLabel label = (JLabel) component;
                    label.setIcon(_view.getSystemIcon(file));
                    label.setText(_view.getSystemDisplayName(file));
                    label.setToolTipText(file.getPath());
                }
            }

            return component;
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        java.awt.GridBagConstraints gridBagConstraints;

        jButtonOK = new javax.swing.JButton();
        jButtonCancel = new javax.swing.JButton();
        jLabelSelection = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTree1 = new javax.swing.JTree();
        jLabel2 = new javax.swing.JLabel();
        jCheckBoxNetwork = new javax.swing.JCheckBox();

        addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                formKeyPressed(evt);
            }
        });
        setLayout(new java.awt.GridBagLayout());

        jButtonOK.setText("Enter");
        jButtonOK.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonOKActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 2;
        add(jButtonOK, gridBagConstraints);

        jButtonCancel.setText("Cancel");
        jButtonCancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonCancelActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 3;
        gridBagConstraints.gridy = 2;
        add(jButtonCancel, gridBagConstraints);

        jLabelSelection.setText("Please Select 1 From Tree");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.gridwidth = 4;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        add(jLabelSelection, gridBagConstraints);

        jTree1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTree1MouseClicked(evt);
            }
        });
        jTree1.addTreeSelectionListener(new javax.swing.event.TreeSelectionListener() {
            public void valueChanged(javax.swing.event.TreeSelectionEvent evt) {
                jTree1ValueChanged(evt);
            }
        });
        jTree1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jTree1KeyPressed(evt);
            }
        });
        jScrollPane1.setViewportView(jTree1);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 3;
        gridBagConstraints.gridwidth = 4;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 1.0;
        add(jScrollPane1, gridBagConstraints);

        jLabel2.setText("-hide");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.weightx = 1.0;
        add(jLabel2, gridBagConstraints);

        jCheckBoxNetwork.setText("Unlock Network Access");
        jCheckBoxNetwork.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBoxNetworkActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 2;
        add(jCheckBoxNetwork, gridBagConstraints);
    }// </editor-fold>//GEN-END:initComponents

    private void jButtonOKActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonOKActionPerformed
        setResultAndClose(_selection);
    }//GEN-LAST:event_jButtonOKActionPerformed

    private void jButtonCancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonCancelActionPerformed
        setResultAndClose(null);
    }//GEN-LAST:event_jButtonCancelActionPerformed

    private void jTree1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTree1MouseClicked
        // TODO add your handling code here:
        if (evt.getClickCount() >= 2) {
            //setResultAndClose(_selection);
        }
    }//GEN-LAST:event_jTree1MouseClicked

    private void jTree1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTree1KeyPressed
        switch (evt.getExtendedKeyCode()) {
            case KeyEvent.VK_ENTER:
                setResultAndClose(_selection);
                return;
            case KeyEvent.VK_ESCAPE:
                setResultAndClose(null);
                return;
        }
    }//GEN-LAST:event_jTree1KeyPressed

    private void formKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_formKeyPressed
        switch (evt.getExtendedKeyCode()) {
            case KeyEvent.VK_ENTER:
                setResultAndClose(_selection);
                return;
            case KeyEvent.VK_ESCAPE:
                setResultAndClose(null);
                return;
        }
    }//GEN-LAST:event_formKeyPressed

    private void jTree1ValueChanged(javax.swing.event.TreeSelectionEvent evt) {//GEN-FIRST:event_jTree1ValueChanged

    }//GEN-LAST:event_jTree1ValueChanged

    private void jCheckBoxNetworkActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBoxNetworkActionPerformed
        // TODO add your handling code here:
        if (_networkNode != null) {
            expandNode(_networkNode, null);
        }
    }//GEN-LAST:event_jCheckBoxNetworkActionPerformed

    public void setResultAndClose(File result) {
        if (result == null) {
            _result = null;
        } else {
            if (result.getPath().startsWith("::")) {
                JOptionPane.showMessageDialog(this, "Can't select System Folder", "notice", JOptionPane.OK_OPTION);
                return;
            }
            _result = result.getAbsoluteFile();
        }
        Container c = MXUtil.getOwnerWindow(this);
        c.setVisible(false);
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonCancel;
    private javax.swing.JButton jButtonOK;
    private javax.swing.JCheckBox jCheckBoxNetwork;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabelSelection;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTree jTree1;
    // End of variables declaration//GEN-END:variables
}
